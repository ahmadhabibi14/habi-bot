"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function hi() {
    return "hi";
}
const services = {
    hi
};
exports.default = services;
