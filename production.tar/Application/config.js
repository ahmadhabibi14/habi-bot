"use strict";
// BOT token disini
Object.defineProperty(exports, "__esModule", { value: true });
exports.dbUrl = exports.botToken = void 0;
exports.botToken = "5450247144:AAFEzzR0jOKuNxhW5BGz3V_5Mq9ijV1sl0U";
exports.dbUrl = "mongodb+srv://ary:komang@cluster0.91nmd.mongodb.net/?retryWrites=true&w=majority";
